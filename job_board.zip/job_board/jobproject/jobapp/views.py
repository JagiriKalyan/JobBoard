from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Job
from django.contrib.auth import logout,login
import re
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.conf import settings
from django.core.mail import send_mail


# Dashboard View
def Dashboard(request):
    return render(request, 'dashboard.html')

# Job List View
@login_required
def job_list(request):
    category = request.GET.get('category', 'all')  # Get category from URL params

    if category and category != 'all':
        jobs = Job.objects.filter(category=category)
    else:
        jobs = Job.objects.all()

    # Get applied jobs for current user
    applied_jobs = request.user.applied_jobs.all()

    return render(request, 'job_list.html', {'jobs': jobs, 'selected_category': category, 'applied_jobs': applied_jobs})

# Apply Job View
@login_required
def apply_job(request, job_id):
    job = get_object_or_404(Job, id=job_id)

    # Check if user has already applied
    if request.user in job.applicants.all():
        messages.warning(request, "You have already applied for this job.")
        return redirect('job_list')

    # Add user to job applicants list
    job.applicants.add(request.user)

    # Send confirmation email
    subject = f"Application Successful: {job.title} at {job.company}"
    message = f"""
    Hi {request.user.username},

    You have successfully applied for:

    📌 Job Title: {job.title}
    🏢 Company: {job.company}
    📍 Location: {job.location}
    📝 Description: {job.description}

    The employer will review your application and contact you soon.

    Best regards,  
    Job Board Team
    """
    send_mail(subject, message, settings.EMAIL_HOST_USER, [request.user.email], fail_silently=False)

    messages.success(request, "You have successfully applied for this job. A confirmation email has been sent.")
    return redirect('job_list')

# Applied Jobs Page
@login_required
def applied_jobs(request):
    category = request.GET.get('category', 'all')  # Get category filter from URL params
    applied_jobs = request.user.applied_jobs.all()

    if category and category != 'all':
        applied_jobs = applied_jobs.filter(category=category)

    return render(request, 'applied_jobs.html', {'jobs': applied_jobs, 'selected_category': category})



# Logout View
def user_login(request):
    if request.method == 'POST':
        username = request.POST['username'].strip()
        password = request.POST['password'].strip()

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, "Login successful!")
            return redirect('job_list')  # Redirect to dashboard after login
        else:
            messages.error(request, "Invalid username or password!")

    return render(request, 'login.html')

# Handle User Logout
@login_required
def user_logout(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect('dashboard')  # Redirect to login page after logout

def is_strong_password(password):
    """ Validate password: At least 8 characters, one number, one special character """
    if len(password) < 8:
        return "Password must be at least 8 characters long."
    if not re.search(r'\d', password):
        return "Password must contain at least one number."
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return "Password must contain at least one special character."
    return None

def register(request):
    if request.method == 'POST':
        username = request.POST['username'].strip()
        email = request.POST['email'].strip()
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        # Check if username is already taken
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return redirect('register')

        # Check if email is valid and not already in use
        if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            messages.error(request, "Invalid email format!")
            return redirect('register')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered!")
            return redirect('register')

        # Check if passwords match
        if password1 != password2:
            messages.error(request, "Passwords do not match!")
            return redirect('register')

        # Validate password strength
        password_error = is_strong_password(password1)
        if password_error:
            messages.error(request, password_error)
            return redirect('register')

        # Create user and redirect to login
        user = User.objects.create_user(username=username, email=email, password=password1)
        user.save()
        messages.success(request, "Registration successful! You can now login.")
        return redirect('login')

    return render(request, 'register.html')
