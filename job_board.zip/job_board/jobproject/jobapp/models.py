from django.db import models
from django.contrib.auth.models import User

class Job(models.Model):
    CATEGORY_CHOICES = [
        ('fresher', 'Fresher'),
        ('internship_paid', 'Internship - Paid'),
        ('internship_unpaid', 'Internship - Unpaid'),
        ('experience', 'Experience'),
    ]

    title = models.CharField(max_length=200)
    company = models.CharField(max_length=200)
    location = models.CharField(max_length=100)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    applicants = models.ManyToManyField(User, related_name="applied_jobs", blank=True)  # Track applied users

    def __str__(self):
        return self.title
